﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Age_of_War
{
    internal class Map
    {
        private int size;

        public Map(int size)
        {
            this.size = size;
            Entity[] carte = new Entity[size];
            Home Base1 = new Home();
            Home Base2 = new Home();
            carte[0] = Base1;
            carte[1] = Base2;
        }

        public int Size
        {
            get
            {
                return size;
            }
            set { size = value; }
        }
    }
}
